import pygame

class SoundManager:

    def __init__(self):
        self.sounds = {
            'click' : pygame.mixer.Sound("assets/assets/sounds/Dababy - LET'S GO sound effect.ogg"),
            'game_over' : pygame.mixer.Sound('assets/assets/sounds/sheesh.ogg'),
            'meteorite': pygame.mixer.Sound('assets/assets/sounds/meteorite.ogg'),
            'damage': pygame.mixer.Sound('assets/assets/sounds/bamboo-hit-sound-effect.ogg'),
            'tir' : pygame.mixer.Sound('assets/assets/sounds/pew-sound-effect-gaming.ogg')
        }
    def play (self,name):
        self.sounds[name].play()