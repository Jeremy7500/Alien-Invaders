import pygame
import math
from game import Game
pygame.init()

#definir une clock
clock = pygame.time.Clock()
FPS = 144

#générer la fenetre de notre jeu
pygame.display.set_caption("Alien Invaders")
screen = pygame.display.set_mode((1600,900))

#importer l'arrière plan du jeu
background = pygame.image.load('assets/assets/bg.jpg')
background = pygame.transform.scale(background, (1600, 900))

#importer charger notre bannière
banner = pygame.image.load('assets/assets/banner.png')
banner = pygame.transform.scale(banner,(500,500))
banner_rect = banner.get_rect()
banner_rect.x = math.ceil(screen.get_width()/3)
banner_rect.y += 50

#importer charger notre bouton pour lancer la partie
play_button = pygame.image.load('assets/assets/button.png')
play_button= pygame.transform.scale(play_button, (400,150))
play_button_rect = play_button.get_rect()
play_button_rect.x= math.ceil(screen.get_width()/3) +60
play_button_rect.y= math.ceil(screen.get_height()/2)

#importer l'icone de la fenêtre
icon = pygame.image.load('assets/assets/alien_icon.png')
icon = pygame.transform.scale(icon, (36, 36))

#charger notre jeu
game = Game()

running = True

#boucle tant que cette condition est vrai
while running :

    #appliquer l'arrière plan de notre jeu
    screen.blit(background , (0,0))

    #verifier si notre jeu a commencé ou non
    if game.is_playing :
        #declencher les instructions de la partie
        game.update(screen)
    #verifier si notre jeu n'a pas commencé
    else :
        #ajouter mon ecran de bienvenue
        screen.blit(banner,banner_rect)
        screen.blit(play_button,play_button_rect)
    #appliquer l'icone de la fenêtre
    pygame.display.set_icon(icon)




    #mettre à jour l'écran
    pygame.display.flip()

    #si le joueur ferme cette fenetre
    for event in pygame.event.get() :
        #que l'evenement est fermeture de fenetre
        if event.type == pygame.QUIT :
            running = False
            pygame.quit()

        #detecter si un joueur appuie une touche du clavier
        elif event.type == pygame.KEYDOWN :
            game.pressed[event.key] = True

            #detecter si la touche espace est enclenchée pour notre projectile
            if event.key == pygame.K_SPACE :
                if game.is_playing:
                    game.player.launch_projectile()
                else :
                    # mettre le jeu en mode 'lancé'
                    game.start()
                    # jouer le son
                    game.sound_manager.play('click')


        # detecter si un joueur lache une touche du clavier
        elif event.type == pygame.KEYUP :
            game.pressed[event.key] = False

        elif event.type == pygame.MOUSEBUTTONDOWN:
            #verification pour savoir si la souris est en collision avec le bouton jouer
            if play_button_rect.collidepoint(event.pos):
                #mettre le jeu en mode 'lancé'
                game.start()
                #jouer le son
                game.sound_manager.play('click')
    #fixer le nombre de fps sur ma clock
    clock.tick(FPS)